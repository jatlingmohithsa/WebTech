# Sample Output :

![image](https://github.com/user-attachments/assets/e4711022-0100-4f4a-9596-2a03b3e1378a)
